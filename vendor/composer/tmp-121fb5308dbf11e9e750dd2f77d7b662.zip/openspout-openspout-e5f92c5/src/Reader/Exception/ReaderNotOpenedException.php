<?php

declare(strict_types=1);

namespace OpenSpout\Reader\Exception;

final class ReaderNotOpenedException extends ReaderException {}
