<?php

namespace Google\ApiCore\LongRunning\Gapic;

if (false) {
    /**
     * This class is deprecated. Use Google\LongRunning\OperationsClient instead.
     * @deprecated
     */
    class OperationsGapicClient extends
        \Google\LongRunning\Client\OperationsClient
    {
    }
}
// Autoload the class and its alias
class_exists('\Google\LongRunning\Gapic\OperationsGapicClient');
