<?php

namespace Spatie\Image\Exceptions;

use Exception;

class MissingParameter extends Exception {}
